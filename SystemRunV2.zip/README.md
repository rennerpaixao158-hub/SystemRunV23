System Run V2 - Use no GitHub Pages.
Abra o index.html no Chrome.